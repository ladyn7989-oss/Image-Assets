# Date With Destiny — A Belly Pet Dating Sim

A visual novel dating simulator featuring 16 unique characters, branching story paths, a world simulation, and deep belly pet mechanics.

## Play on Replit

Just click **Run** — the Python server starts automatically and serves `index.html`.

## Features

### Core Game
- **16 playable characters** with full story routes (7 scenes each)
- **Visual novel engine** with typewriter text, save/load, auto-advance, and skip
- **Affection system** — choices matter, branches unlock at high affection
- **Endless mode** — 20 random scenarios with rotating characters
- **Gallery** — view all unlocked character art

### New in v26
1. **Sound system** — Web Audio API generated SFX (click, type, gift, squirm, encounter, levelup) with volume control and mute toggle
2. **Enhanced gift preferences** — each character now loves AND hates specific gifts, with unique reaction dialogue for major characters
3. **Relationship milestones** — tier system at 10/20/30/40 affection (Stranger → Acquaintance → Close Friend → Intimate → Soulmate)
4. **Branching story paths** — 7 characters have divergent story branches based on your first major choice (Beerus: strict/soft, Champa: fun/serious, Husk: honest/flirty, Vox: ambitious/humble, Anubis: warrior/gentle, Riko: confident/nervous, Fomo: stay/leave)
5. **Special day events** — scripted events on days 7 (Festival of Lights), 14 (Blood Moon), 21 (Twin Eclipse), and 30 (Final Night)
6. **Character Creator Wizard** — 6-step wizard with 8 personality presets (Tsundere, Yandere, Kuudere, Genki, Flirty, Shy, Dominant, Laidback), custom story scenes, belly reactions, and talk trees

### World Simulation
- City map with 7+ explorable locations
- Characters wander between locations each day
- Day/night cycle (4 phases, Riko only appears at night)
- Random encounters while traveling (30% chance)
- Belly pet encounters — predators can eat other characters
- Gift shop with 8 items (coins earned from endless mode)

### Belly Pet System
- Post-ending belly mode with squirm, massage, and talk interactions
- Character-specific belly reactions
- Riko's unique drain mechanic (strength drain bar)
- Multiple prey tracking (Riko can hold multiple characters)
- Special endings: Sentient Fat, Drained, Digest

### Modding
- Import/export custom characters as JSON
- Built-in Character Creator Wizard
- Character format: `{id, name, sub, altEnd, ac, dr, bg, p, e, spr:{}, s:[]}`

## Tech
- Single-file HTML game (no build step needed)
- All assets are URL-based (Google Drive / Base44 CDN)
- Saves use localStorage
- PWA installable on mobile
- Works offline once loaded
